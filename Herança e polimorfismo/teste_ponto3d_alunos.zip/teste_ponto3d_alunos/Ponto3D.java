class Ponto3D{
  
  
}